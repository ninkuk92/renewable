import 'dart:convert';
import 'dart:io';

import '../models/answer_history.dart';
import '../models/study_session.dart';

class ProgressStore {
  ProgressStore._();

  static final ProgressStore instance = ProgressStore._();

  final Map<String, String> _memory = <String, String>{};
  bool _loaded = false;

  String _sessionKey(String sessionId) => 'renewable_exam.session.$sessionId';
  static const String _wrongKey = 'renewable_exam.wrong_ids';
  static const String _bookmarkKey = 'renewable_exam.bookmark_ids';
  static const String _historyKey = 'renewable_exam.answer_history';

  Future<File> _dataFile() async {
    final dir = Directory(
      '${Directory.systemTemp.path}${Platform.pathSeparator}renewable_exam_v203',
    );
    if (!await dir.exists()) {
      await dir.create(recursive: true);
    }
    return File('${dir.path}${Platform.pathSeparator}progress.json');
  }

  Future<void> _ensureLoaded() async {
    if (_loaded) return;
    _loaded = true;
    try {
      final file = await _dataFile();
      if (!await file.exists()) return;
      final raw = await file.readAsString();
      final decoded = jsonDecode(raw);
      if (decoded is Map<String, dynamic>) {
        for (final entry in decoded.entries) {
          final value = entry.value;
          if (value is String) _memory[entry.key] = value;
        }
      }
    } catch (_) {
      // 저장 파일이 손상되어도 앱 실행은 계속한다.
    }
  }

  Future<void> _flush() async {
    try {
      final file = await _dataFile();
      await file.writeAsString(jsonEncode(_memory), flush: true);
    } catch (_) {
      // 저장 실패는 학습 화면 실행을 막지 않는다.
    }
  }

  Future<String?> _read(String key) async {
    await _ensureLoaded();
    return _memory[key];
  }

  Future<void> _write(String key, String value) async {
    await _ensureLoaded();
    _memory[key] = value;
    await _flush();
  }

  Future<void> _remove(String key) async {
    await _ensureLoaded();
    _memory.remove(key);
    await _flush();
  }

  Future<StudySession?> loadSession(String sessionId) async {
    final raw = await _read(_sessionKey(sessionId));
    if (raw == null || raw.isEmpty) return null;
    try {
      final session = StudySession.decode(raw);
      if (session.questionIds.isEmpty) return null;
      return session;
    } catch (_) {
      await _remove(_sessionKey(sessionId));
      return null;
    }
  }

  Future<void> saveSession(StudySession session) async {
    session.updatedAt = DateTime.now();
    await _write(_sessionKey(session.sessionId), session.encode());
  }

  Future<void> clearSession(String sessionId) => _remove(_sessionKey(sessionId));

  Future<StudySession?> loadMostRecentSession() async {
    await _ensureLoaded();
    final sessions = <StudySession>[];
    for (final entry in _memory.entries) {
      if (!entry.key.startsWith('renewable_exam.session.')) continue;
      try {
        final session = StudySession.decode(entry.value);
        if (session.questionIds.isNotEmpty && session.answeredCount > 0) sessions.add(session);
      } catch (_) {
        // 손상된 개별 세션은 건너뛴다.
      }
    }
    if (sessions.isEmpty) return null;
    sessions.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    return sessions.first;
  }

  Future<Set<int>> loadWrongIds() async {
    final ids = await _loadIdSet(_wrongKey);
    final history = await loadHistory();
    final recovered = history.entries.where((e) => e.value.wrongCount > 0).map((e) => e.key);
    final before = ids.length;
    ids.addAll(recovered);
    if (ids.length != before) await _saveIdSet(_wrongKey, ids);
    return ids;
  }
  Future<Set<int>> loadBookmarkIds() => _loadIdSet(_bookmarkKey);

  Future<void> markWrong(int id, {required bool isWrong}) async {
    // 오답 기록은 누적 보존한다. 이후 정답을 맞혀도 과거 오답 이력은 삭제하지 않는다.
    if (!isWrong) return;
    final ids = await loadWrongIds();
    ids.add(id);
    await _saveIdSet(_wrongKey, ids);
  }

  Future<bool> toggleBookmark(int id) async {
    final ids = await loadBookmarkIds();
    final nowBookmarked = !ids.contains(id);
    if (nowBookmarked) {
      ids.add(id);
    } else {
      ids.remove(id);
    }
    await _saveIdSet(_bookmarkKey, ids);
    return nowBookmarked;
  }

  Future<Map<int, AnswerHistory>> loadHistory() async {
    final raw = await _read(_historyKey);
    if (raw == null || raw.isEmpty) return <int, AnswerHistory>{};
    try {
      final decoded = jsonDecode(raw) as Map<String, dynamic>;
      return decoded.map(
        (key, value) => MapEntry(
          int.parse(key),
          AnswerHistory.fromJson(Map<String, dynamic>.from(value as Map)),
        ),
      );
    } catch (_) {
      await _remove(_historyKey);
      return <int, AnswerHistory>{};
    }
  }

  Future<void> recordAnswer(int id, {required bool correct}) async {
    final history = await loadHistory();
    final old = history[id] ??
        const AnswerHistory(attempts: 0, correctCount: 0, wrongCount: 0, lastCorrect: false);
    history[id] = AnswerHistory(
      attempts: old.attempts + 1,
      correctCount: old.correctCount + (correct ? 1 : 0),
      wrongCount: old.wrongCount + (correct ? 0 : 1),
      lastCorrect: correct,
    );
    final payload = history.map((key, value) => MapEntry(key.toString(), value.toJson()));
    await _write(_historyKey, jsonEncode(payload));
  }

  Future<void> resetAllLearningData() async {
    await _ensureLoaded();
    _memory.removeWhere((key, value) => key.startsWith('renewable_exam.'));
    await _flush();
  }

  Future<Set<int>> _loadIdSet(String key) async {
    final raw = await _read(key);
    if (raw == null || raw.isEmpty) return <int>{};
    try {
      final list = jsonDecode(raw) as List<dynamic>;
      return list.map((e) => (e as num).toInt()).toSet();
    } catch (_) {
      await _remove(key);
      return <int>{};
    }
  }

  Future<void> _saveIdSet(String key, Set<int> ids) async {
    final sorted = ids.toList()..sort();
    await _write(key, jsonEncode(sorted));
  }
}
