import 'dart:convert';

import 'package:flutter/services.dart';

import '../models/exam_archive_entry.dart';

class ExamArchiveRepository {
  ExamArchiveRepository._();

  static final ExamArchiveRepository instance = ExamArchiveRepository._();

  List<ExamArchiveEntry>? _cache;

  Future<List<ExamArchiveEntry>> load() async {
    if (_cache != null) return _cache!;
    final raw = await rootBundle.loadString('assets/exam_catalog.json');
    final decoded = jsonDecode(raw);
    if (decoded is! List<dynamic>) {
      throw const FormatException('exam_catalog.json 최상위 형식이 배열이 아닙니다.');
    }
    final items = decoded
        .map((e) => ExamArchiveEntry.fromJson(Map<String, dynamic>.from(e as Map)))
        .where((e) => e.id.isNotEmpty)
        .toList(growable: false);
    if (items.isEmpty) throw const FormatException('과년도 기출 목록이 비어 있습니다.');
    _cache = List<ExamArchiveEntry>.unmodifiable(items);
    return _cache!;
  }
}
