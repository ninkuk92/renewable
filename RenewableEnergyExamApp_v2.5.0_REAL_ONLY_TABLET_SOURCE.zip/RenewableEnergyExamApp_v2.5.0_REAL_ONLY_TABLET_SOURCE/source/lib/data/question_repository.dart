import 'dart:convert';

import 'package:flutter/services.dart';

import '../models/question.dart';

class QuestionRepository {
  QuestionRepository._();
  static final QuestionRepository instance = QuestionRepository._();

  List<ExamQuestion>? _realCache;

  Future<List<ExamQuestion>> loadBundled() => loadReal();

  Future<List<ExamQuestion>> loadReal({bool refresh = false}) async {
    if (!refresh && _realCache != null) return _realCache!;
    _realCache = await _loadAsset('assets/questions.json');
    return _realCache!;
  }

  void invalidateReal() => _realCache = null;

  Future<List<ExamQuestion>> loadExam(String examId) async {
    final all = await loadReal();
    final result = all.where((q) => q.examDate == examId || q.examId == examId).toList(growable: false)
      ..sort((a, b) => a.displayNumber.compareTo(b.displayNumber));
    return result;
  }

  Future<List<ExamQuestion>> _loadAsset(String asset) async {
    final raw = await rootBundle.loadString(asset);
    final decoded = jsonDecode(raw);
    if (decoded is! List<dynamic>) throw FormatException('$asset 최상위 형식이 배열이 아닙니다.');
    final result = decoded.map((e) => ExamQuestion.fromJson(Map<String, dynamic>.from(e as Map))).toList(growable: false);
    if (result.isEmpty) throw FormatException('$asset 문제 데이터가 비어 있습니다.');
    return List<ExamQuestion>.unmodifiable(result);
  }

  Future<List<ExamQuestion>> realByIds(Iterable<int> ids) async {
    final all = await loadReal(); final map = <int, ExamQuestion>{for (final q in all) q.id: q};
    return ids.map((id) => map[id]).whereType<ExamQuestion>().toList(growable: false);
  }
  Future<List<ExamQuestion>> anyByIds(Iterable<int> ids) async {
    final all = await loadReal(); final map = <int, ExamQuestion>{for (final q in all) q.id: q};
    return ids.map((id) => map[id]).whereType<ExamQuestion>().toList(growable: false);
  }
}
