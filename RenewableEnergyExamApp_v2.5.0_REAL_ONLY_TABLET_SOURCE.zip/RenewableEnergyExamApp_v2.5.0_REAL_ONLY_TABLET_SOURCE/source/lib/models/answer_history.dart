class AnswerHistory {
  const AnswerHistory({
    required this.attempts,
    required this.correctCount,
    required this.wrongCount,
    required this.lastCorrect,
  });

  final int attempts;
  final int correctCount;
  final int wrongCount;
  final bool lastCorrect;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'attempts': attempts,
        'correctCount': correctCount,
        'wrongCount': wrongCount,
        'lastCorrect': lastCorrect,
      };

  factory AnswerHistory.fromJson(Map<String, dynamic> json) => AnswerHistory(
        attempts: (json['attempts'] as num?)?.toInt() ?? 0,
        correctCount: (json['correctCount'] as num?)?.toInt() ?? 0,
        wrongCount: (json['wrongCount'] as num?)?.toInt() ?? 0,
        lastCorrect: (json['lastCorrect'] as bool?) ?? false,
      );
}
