import 'dart:convert';

class StudySession {
  StudySession({
    required this.sessionId,
    required this.questionIds,
    this.currentIndex = 0,
    Map<int, int>? answers,
    Set<int>? revealedIds,
    DateTime? updatedAt,
    this.completed = false,
  })  : answers = answers ?? <int, int>{},
        revealedIds = revealedIds ?? <int>{},
        updatedAt = updatedAt ?? DateTime.now();

  final String sessionId;
  final List<int> questionIds;
  int currentIndex;
  final Map<int, int> answers;
  final Set<int> revealedIds;
  DateTime updatedAt;
  bool completed;

  int get answeredCount => revealedIds.length;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'sessionId': sessionId,
        'questionIds': questionIds,
        'currentIndex': currentIndex,
        'answers': answers.map((key, value) => MapEntry(key.toString(), value)),
        'revealedIds': revealedIds.toList(),
        'updatedAt': updatedAt.toIso8601String(),
        'completed': completed,
      };

  String encode() => jsonEncode(toJson());

  factory StudySession.decode(String raw) {
    final decoded = jsonDecode(raw);
    if (decoded is! Map<String, dynamic>) {
      throw const FormatException('학습 세션 형식이 올바르지 않습니다.');
    }
    final answerJson =
        (decoded['answers'] as Map<String, dynamic>?) ?? <String, dynamic>{};
    return StudySession(
      sessionId: (decoded['sessionId'] as String?) ?? '',
      questionIds: ((decoded['questionIds'] as List<dynamic>?) ?? const <dynamic>[])
          .map((e) => (e as num).toInt())
          .toList(),
      currentIndex: (decoded['currentIndex'] as num?)?.toInt() ?? 0,
      answers: answerJson.map(
        (key, value) => MapEntry(int.parse(key), (value as num).toInt()),
      ),
      revealedIds: ((decoded['revealedIds'] as List<dynamic>?) ?? const <dynamic>[])
          .map((e) => (e as num).toInt())
          .toSet(),
      updatedAt: DateTime.tryParse((decoded['updatedAt'] as String?) ?? '') ??
          DateTime.now(),
      completed: (decoded['completed'] as bool?) ?? false,
    );
  }
}
