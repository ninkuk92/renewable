class ExamArchiveEntry {
  const ExamArchiveEntry({
    required this.id,
    required this.year,
    required this.dateLabel,
    required this.round,
    required this.questionCount,
    required this.subjectCount,
    required this.mode,
    required this.sourceUrl,
    required this.note,
    this.cbtBankUrl = '',
  });

  final String id;
  final int year;
  final String dateLabel;
  final String round;
  final int questionCount;
  final int subjectCount;
  final String mode;
  final String sourceUrl;
  final String note;
  final String cbtBankUrl;

  bool get isBundled => mode == 'bundled' || mode == 'offline';
  bool get needsSync => !isBundled;
  String get compactDate => id.replaceAll('-', '');

  factory ExamArchiveEntry.fromJson(Map<String, dynamic> json) {
    final id = json['id']?.toString() ?? '';
    final subjectCount = (json['subjectCount'] as num?)?.toInt() ?? 0;
    return ExamArchiveEntry(
      id: id,
      year: (json['year'] as num?)?.toInt() ?? 0,
      dateLabel: json['dateLabel']?.toString() ?? '',
      round: json['round']?.toString() ?? '',
      questionCount: (json['questionCount'] as num?)?.toInt() ?? 0,
      subjectCount: subjectCount,
      mode: json['mode']?.toString() ?? 'sync',
      sourceUrl: json['sourceUrl']?.toString() ?? '',
      note: json['note']?.toString() ?? '',
      cbtBankUrl: json['cbtBankUrl']?.toString() ??
          (id.isEmpty ? '' : 'https://cbtbank.kr/exam/${subjectCount == 4 ? 'rr' : 'dt'}${id.replaceAll('-', '')}'),
    );
  }
}
