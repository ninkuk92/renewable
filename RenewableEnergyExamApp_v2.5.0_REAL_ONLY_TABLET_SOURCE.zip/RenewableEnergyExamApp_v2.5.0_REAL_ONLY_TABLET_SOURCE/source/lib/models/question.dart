class ExamQuestion {
  const ExamQuestion({
    required this.id,
    required this.year,
    required this.examDate,
    required this.subject,
    required this.question,
    required this.choices,
    required this.answer,
    required this.source,
    this.number = 0,
    this.examId = '',
    this.note = '',
    this.explanation = '',
    this.aiAnswer = '',
    this.memoryTip = '',
    this.imageAsset = '',
    this.imageAssets = const <String>[],
    this.sourceUrl = '',
    this.basisTitle = '',
    this.basisDetail = '',
    this.basisUrl = '',
    this.verificationStatus = '',
    this.basisLevel = '',
    this.currentNote = '',
    this.conceptNote = '',
    this.evidenceCheckedAt = '',
    this.choiceAnalysis = const <String>[],
    this.predicted = false,
  });

  final int id;
  final int year;
  final String examDate;
  final String subject;
  final String question;
  final List<String> choices;
  final int answer;
  final String source;
  final int number;
  final String examId;
  final String note;
  final String explanation;
  final String aiAnswer;
  final String memoryTip;
  final String imageAsset;
  final List<String> imageAssets;
  final String sourceUrl;
  final String basisTitle;
  final String basisDetail;
  final String basisUrl;
  final String verificationStatus;
  final String basisLevel;
  final String currentNote;
  final String conceptNote;
  final String evidenceCheckedAt;
  final List<String> choiceAnalysis;
  final bool predicted;

  int get displayNumber => number > 0 ? number : id;

  factory ExamQuestion.fromJson(Map<String, dynamic> json) {
    final id = (json['id'] as num).toInt();
    final predicted = (json['predicted'] as bool?) ?? false;
    final examDate = (json['examDate'] as String?) ?? '';
    final imageAsset = (json['imageAsset'] as String?) ?? '';
    final imageAssets = ((json['imageAssets'] as List<dynamic>?) ?? const <dynamic>[])
        .map((e) => e.toString())
        .where((e) => e.isNotEmpty)
        .toList(growable: false);
    return ExamQuestion(
      id: id,
      year: (json['year'] as num).toInt(),
      examDate: examDate,
      subject: (json['subject'] as String?) ?? '',
      question: (json['question'] as String?) ?? '',
      choices: ((json['choices'] as List<dynamic>?) ?? const <dynamic>[])
          .map((e) => e.toString())
          .toList(growable: false),
      answer: (json['answer'] as num).toInt(),
      source: (json['source'] as String?) ?? '',
      number: (json['number'] as num?)?.toInt() ?? (predicted ? 0 : id),
      examId: (json['examId'] as String?) ?? (predicted ? 'AI-PREDICTED' : examDate),
      note: (json['note'] as String?) ?? '',
      explanation: (json['explanation'] as String?) ?? '',
      aiAnswer: (json['aiAnswer'] as String?) ?? '',
      memoryTip: (json['memoryTip'] as String?) ?? '',
      imageAsset: imageAsset,
      imageAssets: imageAssets.isNotEmpty
          ? imageAssets
          : (imageAsset.isEmpty ? const <String>[] : <String>[imageAsset]),
      sourceUrl: (json['sourceUrl'] as String?) ?? '',
      basisTitle: (json['basisTitle'] as String?) ?? '',
      basisDetail: (json['basisDetail'] as String?) ?? '',
      basisUrl: (json['basisUrl'] as String?) ?? '',
      verificationStatus: (json['verificationStatus'] as String?) ?? '',
      basisLevel: (json['basisLevel'] as String?) ?? '',
      currentNote: (json['currentNote'] as String?) ?? '',
      conceptNote: (json['conceptNote'] as String?) ?? '',
      evidenceCheckedAt: (json['evidenceCheckedAt'] as String?) ?? '',
      choiceAnalysis: ((json['choiceAnalysis'] as List<dynamic>?) ?? const <dynamic>[])
          .map((e) => e.toString())
          .toList(growable: false),
      predicted: predicted,
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'year': year,
        'examDate': examDate,
        'examId': examId,
        'number': displayNumber,
        'subject': subject,
        'question': question,
        'choices': choices,
        'answer': answer,
        'source': source,
        'note': note,
        'explanation': explanation,
        'aiAnswer': aiAnswer,
        'memoryTip': memoryTip,
        'imageAsset': imageAsset,
        'imageAssets': imageAssets,
        'sourceUrl': sourceUrl,
        'basisTitle': basisTitle,
        'basisDetail': basisDetail,
        'basisUrl': basisUrl,
        'verificationStatus': verificationStatus,
        'basisLevel': basisLevel,
        'currentNote': currentNote,
        'conceptNote': conceptNote,
        'evidenceCheckedAt': evidenceCheckedAt,
        'choiceAnalysis': choiceAnalysis,
        'predicted': predicted,
      };
}
