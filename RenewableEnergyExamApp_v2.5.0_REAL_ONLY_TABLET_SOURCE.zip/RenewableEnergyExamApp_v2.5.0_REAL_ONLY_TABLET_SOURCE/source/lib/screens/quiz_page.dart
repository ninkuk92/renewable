import 'dart:async';

import 'package:flutter/material.dart';

import '../data/progress_store.dart';
import '../models/question.dart';
import '../models/study_session.dart';
import 'source_check_page.dart';

class QuizPage extends StatefulWidget {
  const QuizPage({
    super.key,
    required this.title,
    required this.sessionId,
    required this.questions,
  });

  final String title;
  final String sessionId;
  final List<ExamQuestion> questions;

  @override
  State<QuizPage> createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> with WidgetsBindingObserver {
  final ProgressStore _store = ProgressStore.instance;
  StudySession? _session;
  Set<int> _bookmarks = <int>{};
  bool _loading = true;
  String? _loadError;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    unawaited(_load());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    final session = _session;
    if (session != null) unawaited(_store.saveSession(session));
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.inactive ||
        state == AppLifecycleState.paused ||
        state == AppLifecycleState.detached) {
      final session = _session;
      if (session != null) unawaited(_store.saveSession(session));
    }
  }

  Future<void> _load() async {
    try {
      if (widget.questions.isEmpty) throw StateError('표시할 문제가 없습니다.');
      final ids = widget.questions.map((q) => q.id).toList(growable: false);
      var session = await _store.loadSession(widget.sessionId);
      if (session == null ||
          !_sameIds(session.questionIds, ids) ||
          session.currentIndex < 0 ||
          session.currentIndex >= ids.length) {
        session = StudySession(sessionId: widget.sessionId, questionIds: ids);
        await _store.saveSession(session);
      }
      final bookmarks = await _store.loadBookmarkIds();
      if (!mounted) return;
      setState(() {
        _session = session;
        _bookmarks = bookmarks;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loadError = e.toString();
        _loading = false;
      });
    }
  }

  bool _sameIds(List<int> a, List<int> b) {
    if (a.length != b.length) return false;
    for (var i = 0; i < a.length; i++) {
      if (a[i] != b[i]) return false;
    }
    return true;
  }

  ExamQuestion get _question => widget.questions[_session!.currentIndex];

  Future<void> _selectAnswer(int answer) async {
    final session = _session!;
    final q = _question;
    if (session.revealedIds.contains(q.id)) return;

    session.answers[q.id] = answer;
    session.revealedIds.add(q.id);
    session.completed = session.revealedIds.length == widget.questions.length;
    final correct = answer == q.answer;
    setState(() {});

    await Future.wait(<Future<void>>[
      _store.saveSession(session),
      _store.markWrong(q.id, isWrong: !correct),
      _store.recordAnswer(q.id, correct: correct),
    ]);
  }

  Future<void> _goTo(int index) async {
    if (index < 0 || index >= widget.questions.length) return;
    _session!.currentIndex = index;
    setState(() {});
    await _store.saveSession(_session!);
  }

  Future<void> _toggleBookmark() async {
    final id = _question.id;
    final bookmarked = await _store.toggleBookmark(id);
    if (!mounted) return;
    setState(() {
      if (bookmarked) {
        _bookmarks.add(id);
      } else {
        _bookmarks.remove(id);
      }
    });
  }

  double _questionFontSize(String text) {
    if (text.length >= 220) return 15.5;
    if (text.length >= 150) return 16.0;
    if (text.length >= 95) return 17.0;
    return 18.5;
  }

  int _displayNumber(int index, ExamQuestion q) => q.predicted ? index + 1 : q.displayNumber;

  void _showQuestionList() {
    final session = _session!;
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) {
        return SafeArea(
          child: SizedBox(
            height: MediaQuery.of(context).size.height * 0.72,
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 0, 18, 10),
                  child: Row(
                    children: <Widget>[
                      const Expanded(
                        child: Text('전체 문제 목록', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                      ),
                      Text('${session.revealedIds.length}/${widget.questions.length} 풀이'),
                    ],
                  ),
                ),
                Expanded(
                  child: GridView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 5,
                      mainAxisSpacing: 8,
                      crossAxisSpacing: 8,
                    ),
                    itemCount: widget.questions.length,
                    itemBuilder: (_, index) {
                      final q = widget.questions[index];
                      final revealed = session.revealedIds.contains(q.id);
                      final selected = session.answers[q.id];
                      final correct = revealed && selected == q.answer;
                      final current = index == session.currentIndex;
                      final bookmarked = _bookmarks.contains(q.id);
                      Color? background;
                      Color? foreground;
                      if (current) {
                        background = Theme.of(context).colorScheme.primary;
                        foreground = Theme.of(context).colorScheme.onPrimary;
                      } else if (revealed && correct) {
                        background = Theme.of(context).colorScheme.primaryContainer;
                      } else if (revealed) {
                        background = Theme.of(context).colorScheme.errorContainer;
                      }
                      return Stack(
                        children: <Widget>[
                          Positioned.fill(
                            child: Material(
                              color: background ?? Theme.of(context).colorScheme.surfaceContainerHighest,
                              borderRadius: BorderRadius.circular(12),
                              child: InkWell(
                                borderRadius: BorderRadius.circular(12),
                                onTap: () {
                                  Navigator.pop(sheetContext);
                                  unawaited(_goTo(index));
                                },
                                child: Center(
                                  child: Text(
                                    '${_displayNumber(index, q)}',
                                    style: TextStyle(fontWeight: FontWeight.w800, color: foreground),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          if (bookmarked)
                            const Positioned(
                              right: 3,
                              top: 3,
                              child: Icon(Icons.star, size: 13),
                            ),
                        ],
                      );
                    },
                  ),
                ),
                const Padding(
                  padding: EdgeInsets.fromLTRB(16, 0, 16, 16),
                  child: Text('초록: 정답 · 빨강: 오답 · 별: 중요문제 · 진한색: 현재 문제'),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showAiExplanation(ExamQuestion q) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) {
        final hasOfficialBasis = q.basisUrl.isNotEmpty;
        final aiBody = q.aiAnswer.isNotEmpty
            ? q.aiAnswer
            : (q.explanation.isNotEmpty ? q.explanation : '해설 데이터가 없습니다.');
        return SafeArea(
          child: SizedBox(
            height: MediaQuery.of(context).size.height * 0.9,
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 10),
                  child: Row(
                    children: <Widget>[
                      const Icon(Icons.auto_awesome),
                      const SizedBox(width: 8),
                      const Expanded(
                        child: Text('AI 답변 해설', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                      ),
                      Chip(label: Text('${q.examDate} 기출')),
                    ],
                  ),
                ),
                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(20, 4, 20, 28),
                    children: <Widget>[
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              const Text('정답', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800)),
                              const SizedBox(height: 6),
                              Text(
                                '${q.answer}번 · ${q.choices[q.answer - 1]}',
                                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, height: 1.4),
                              ),
                              if (q.verificationStatus.isNotEmpty) ...<Widget>[
                                const SizedBox(height: 10),
                                Wrap(
                                  spacing: 6,
                                  runSpacing: 6,
                                  children: <Widget>[
                                    Chip(
                                      avatar: const Icon(Icons.verified_outlined, size: 17),
                                      label: Text(q.verificationStatus),
                                    ),
                                    if (q.basisLevel.isNotEmpty)
                                      Chip(
                                        avatar: const Icon(Icons.shield_outlined, size: 17),
                                        label: Text(q.basisLevel),
                                      ),
                                    if (q.evidenceCheckedAt.isNotEmpty)
                                      Chip(label: Text('근거정리 ${q.evidenceCheckedAt}')),
                                  ],
                                ),
                              ],
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      _ExplanationSection(
                        icon: Icons.auto_awesome_rounded,
                        title: 'AI 답변',
                        body: aiBody,
                      ),
                      if (q.choiceAnalysis.length == q.choices.length) ...<Widget>[
                        const SizedBox(height: 10),
                        Card(
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                const Row(
                                  children: <Widget>[
                                    Icon(Icons.fact_check_outlined),
                                    SizedBox(width: 8),
                                    Text('보기별 검토', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                                  ],
                                ),
                                const SizedBox(height: 10),
                                for (var i = 0; i < q.choices.length; i++) ...<Widget>[
                                  Text(
                                    '${i + 1}. ${q.choices[i]}',
                                    style: TextStyle(
                                      fontWeight: i + 1 == q.answer ? FontWeight.w900 : FontWeight.w700,
                                      height: 1.45,
                                    ),
                                  ),
                                  const SizedBox(height: 3),
                                  Text(q.choiceAnalysis[i], style: const TextStyle(fontSize: 13.5, height: 1.45)),
                                  if (i != q.choices.length - 1) const Divider(height: 18),
                                ],
                              ],
                            ),
                          ),
                        ),
                      ],
                      const SizedBox(height: 10),
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              const Row(
                                children: <Widget>[
                                  Icon(Icons.gavel_outlined),
                                  SizedBox(width: 8),
                                  Text('검증 근거', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                                ],
                              ),
                              const SizedBox(height: 10),
                              Text(
                                q.basisTitle.isEmpty ? q.source : q.basisTitle,
                                style: const TextStyle(fontWeight: FontWeight.w800, height: 1.45),
                              ),
                              if (q.basisDetail.isNotEmpty) ...<Widget>[
                                const SizedBox(height: 7),
                                Text(q.basisDetail, style: const TextStyle(height: 1.55)),
                              ],
                              const SizedBox(height: 8),
                              Text(
                                '기출 정답 1차 근거: ${q.source}',
                                style: const TextStyle(fontSize: 13.5, height: 1.45),
                              ),
                              if (hasOfficialBasis) ...<Widget>[
                                const SizedBox(height: 12),
                                SizedBox(
                                  width: double.infinity,
                                  child: OutlinedButton.icon(
                                    onPressed: () => Navigator.of(sheetContext).push<void>(
                                      MaterialPageRoute<void>(
                                        builder: (_) => SourceCheckPage(
                                          title: '${q.displayNumber}번 공식 근거 확인',
                                          url: q.basisUrl,
                                        ),
                                      ),
                                    ),
                                    icon: const Icon(Icons.open_in_new_rounded),
                                    label: const Text('공식 근거 주소 확인 / 복사'),
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                      ),
                      if (q.currentNote.isNotEmpty) ...<Widget>[
                        const SizedBox(height: 10),
                        Card(
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                const Icon(Icons.history_rounded),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: <Widget>[
                                      const Text('출제 당시 기준 vs 현재 기준', style: TextStyle(fontWeight: FontWeight.w900)),
                                      const SizedBox(height: 5),
                                      Text(q.currentNote, style: const TextStyle(height: 1.5)),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                      if (q.memoryTip.isNotEmpty) ...<Widget>[
                        const SizedBox(height: 10),
                        Card(
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                const Icon(Icons.psychology_alt_outlined),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: <Widget>[
                                      const Text('시험 포인트', style: TextStyle(fontWeight: FontWeight.w900)),
                                      const SizedBox(height: 4),
                                      Text(q.memoryTip, style: const TextStyle(height: 1.45)),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                      const SizedBox(height: 12),
                      const Text(
                        '※ AI 답변형 해설은 교사용 원문 정답과 앱에 내장된 검증 데이터를 바탕으로 작성했습니다. 실시간 AI 호출이 아니며, 확인되지 않은 조문·수치·근거는 임의로 생성하지 않습니다. A=계산 재검산/공식 기준코드 확인, B=공식 근거처 연결, C=교사용 원문 정답 + 이론 검토입니다.',
                        style: const TextStyle(fontSize: 12.5, height: 1.5),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  List<ExamQuestion> _wrongQuestionsInSession(StudySession session) {
    return widget.questions
        .where((question) => session.revealedIds.contains(question.id))
        .where((question) => session.answers[question.id] != question.answer)
        .toList(growable: false);
  }

  Future<void> _retryWrongOnly() async {
    final session = _session;
    if (session == null) return;
    final globalWrongIds = await _store.loadWrongIds();
    final wrongQuestions = widget.questions
        .where((question) => globalWrongIds.contains(question.id))
        .toList(growable: false);
    if (!mounted) return;
    if (wrongQuestions.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('누적 오답 기록이 없습니다.')),
      );
      return;
    }
    final retrySessionId = '${widget.sessionId}.wrong-retry';
    await _store.clearSession(retrySessionId);
    if (!mounted) return;
    await Navigator.of(context).push<void>(
      MaterialPageRoute<void>(
        builder: (_) => QuizPage(
          title: '누적 오답 ${wrongQuestions.length}문제 다시 풀기',
          sessionId: retrySessionId,
          questions: wrongQuestions,
        ),
      ),
    );
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Scaffold(
        appBar: AppBar(title: Text(widget.title)),
        body: const Center(child: CircularProgressIndicator()),
      );
    }
    if (_loadError != null || _session == null) {
      return Scaffold(
        appBar: AppBar(title: Text(widget.title)),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text(
              '문제풀이 화면을 불러오지 못했습니다.\n${_loadError ?? '알 수 없는 오류'}',
              textAlign: TextAlign.center,
            ),
          ),
        ),
      );
    }

    final session = _session!;
    final q = _question;
    final selected = session.answers[q.id];
    final revealed = session.revealedIds.contains(q.id);
    final isBookmarked = _bookmarks.contains(q.id);
    final progress = (session.currentIndex + 1) / widget.questions.length;
    final displayNo = _displayNumber(session.currentIndex, q);
    final sessionWrongQuestions = _wrongQuestionsInSession(session);
    final sessionWrongCount = sessionWrongQuestions.length;
    final sessionCorrectCount = session.revealedIds.length - sessionWrongCount;

    return PopScope(
      canPop: true,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) unawaited(_store.saveSession(session));
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(widget.title, overflow: TextOverflow.ellipsis),
          actions: <Widget>[
            IconButton(
              tooltip: '전체 문제 목록',
              onPressed: _showQuestionList,
              icon: const Icon(Icons.grid_view_rounded),
            ),
            IconButton(
              tooltip: isBookmarked ? '중요문제 해제' : '중요문제로 저장',
              onPressed: _toggleBookmark,
              icon: Icon(isBookmarked ? Icons.star : Icons.star_border),
            ),
          ],
        ),
        body: SafeArea(
          child: Column(
            children: <Widget>[
              LinearProgressIndicator(value: progress),
              if (session.completed)
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 10, 12, 0),
                  child: Card(
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Row(
                            children: <Widget>[
                              const Icon(Icons.flag_circle_outlined),
                              const SizedBox(width: 8),
                              const Text('이번 풀이 완료', style: TextStyle(fontWeight: FontWeight.w900)),
                              const Spacer(),
                              Text('정답 $sessionCorrectCount · 오답 $sessionWrongCount'),
                            ],
                          ),
                          if (sessionWrongCount > 0) ...<Widget>[
                            const SizedBox(height: 10),
                            SizedBox(
                              width: double.infinity,
                              child: FilledButton.icon(
                                onPressed: _retryWrongOnly,
                                icon: const Icon(Icons.restart_alt_rounded),
                                label: const Text('누적 오답 기록 전체 다시 풀기'),
                              ),
                            ),
                          ] else ...<Widget>[
                            const SizedBox(height: 8),
                            const Text('이번 세트는 모두 맞혔습니다. 과거 오답 기록은 삭제되지 않습니다.'),
                          ],
                        ],
                      ),
                    ),
                  ),
                ),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Flexible(child: Chip(label: Text(q.subject))),
                        const Spacer(),
                        Text(
                          '$displayNo / ${widget.questions.length}',
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    Text(
                      '$displayNo. ${q.question}',
                      style: TextStyle(
                        fontSize: _questionFontSize(q.question),
                        fontWeight: FontWeight.w800,
                        height: 1.55,
                      ),
                    ),
                    if (q.imageAssets.isNotEmpty || q.imageAsset.isNotEmpty) ...<Widget>[
                      const SizedBox(height: 16),
                      Card(
                        clipBehavior: Clip.antiAlias,
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                '원문 그림 / 보기 · ${(q.imageAssets.isNotEmpty ? q.imageAssets : <String>[q.imageAsset]).length}개',
                                style: const TextStyle(fontWeight: FontWeight.w800),
                              ),
                              const SizedBox(height: 10),
                              for (var imageIndex = 0; imageIndex < (q.imageAssets.isNotEmpty ? q.imageAssets : <String>[q.imageAsset]).length; imageIndex++) ...<Widget>[
                                if ((q.imageAssets.isNotEmpty ? q.imageAssets : <String>[q.imageAsset]).length > 1)
                                  Padding(
                                    padding: const EdgeInsets.only(bottom: 6),
                                    child: Text(
                                      '원문 이미지 ${imageIndex + 1}/${(q.imageAssets.isNotEmpty ? q.imageAssets : <String>[q.imageAsset]).length}',
                                      style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700),
                                    ),
                                  ),
                                Center(
                                  child: Image.asset(
                                    (q.imageAssets.isNotEmpty ? q.imageAssets : <String>[q.imageAsset])[imageIndex],
                                    fit: BoxFit.contain,
                                    errorBuilder: (_, __, ___) => const Padding(
                                      padding: EdgeInsets.all(16),
                                      child: Text('원문 이미지를 표시하지 못했습니다.'),
                                    ),
                                  ),
                                ),
                                if (imageIndex + 1 < (q.imageAssets.isNotEmpty ? q.imageAssets : <String>[q.imageAsset]).length)
                                  const Divider(height: 24),
                              ],
                            ],
                          ),
                        ),
                      ),
                    ],
                    if (q.note.isNotEmpty) ...<Widget>[
                      const SizedBox(height: 10),
                      Text(q.note, style: Theme.of(context).textTheme.bodySmall?.copyWith(height: 1.45)),
                      if (q.sourceUrl.isNotEmpty) ...<Widget>[
                        const SizedBox(height: 8),
                        OutlinedButton.icon(
                          onPressed: () => Navigator.of(context).push<void>(
                            MaterialPageRoute<void>(
                              builder: (_) => SourceCheckPage(title: '${q.examDate} ${q.displayNumber}번 원문 확인', url: q.sourceUrl),
                            ),
                          ),
                          icon: const Icon(Icons.description_outlined),
                          label: const Text('그림·표 원문 확인'),
                        ),
                      ],
                    ],
                    const SizedBox(height: 18),
                    for (var i = 0; i < q.choices.length; i++)
                      _AnswerTile(
                        number: i + 1,
                        text: q.choices[i],
                        selected: selected == i + 1,
                        correct: revealed && q.answer == i + 1,
                        wrong: revealed && selected == i + 1 && selected != q.answer,
                        enabled: !revealed,
                        onTap: () => _selectAnswer(i + 1),
                      ),
                    if (revealed) ...<Widget>[
                      const SizedBox(height: 6),
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(14),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Icon(selected == q.answer ? Icons.check_circle : Icons.cancel),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  selected == q.answer
                                      ? '정답입니다. · ${q.answer}번 ${q.choices[q.answer - 1]}'
                                      : '오답입니다. · 정답 ${q.answer}번 ${q.choices[q.answer - 1]}',
                                  style: const TextStyle(fontWeight: FontWeight.w800, height: 1.45),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      SizedBox(
                        width: double.infinity,
                        child: FilledButton.icon(
                          onPressed: () => _showAiExplanation(q),
                          icon: const Icon(Icons.auto_awesome),
                          label: const Text('AI 답변으로 해설 보기'),
                        ),
                      ),
                    ] else ...<Widget>[
                      const SizedBox(height: 6),
                      const Text('답을 선택하면 정답과 AI 답변 해설을 확인할 수 있습니다.'),
                    ],
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
                decoration: BoxDecoration(
                  border: Border(top: BorderSide(color: Theme.of(context).dividerColor)),
                  color: Theme.of(context).colorScheme.surface,
                ),
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: OutlinedButton(
                        onPressed: session.currentIndex > 0
                            ? () => _goTo(session.currentIndex - 1)
                            : null,
                        child: const Text('이전'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    IconButton.filledTonal(
                      tooltip: '문제 목록',
                      onPressed: _showQuestionList,
                      icon: const Icon(Icons.apps_rounded),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: FilledButton(
                        onPressed: session.currentIndex < widget.questions.length - 1
                            ? () => _goTo(session.currentIndex + 1)
                            : null,
                        child: Text(session.currentIndex == widget.questions.length - 1 ? '마지막' : '다음'),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ExplanationSection extends StatelessWidget {
  const _ExplanationSection({required this.icon, required this.title, required this.body});

  final IconData icon;
  final String title;
  final String body;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                Icon(icon),
                const SizedBox(width: 8),
                Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
              ],
            ),
            const SizedBox(height: 9),
            SelectableText(body, style: const TextStyle(fontSize: 15.5, height: 1.62)),
          ],
        ),
      ),
    );
  }
}

class _AnswerTile extends StatelessWidget {
  const _AnswerTile({
    required this.number,
    required this.text,
    required this.selected,
    required this.correct,
    required this.wrong,
    required this.enabled,
    required this.onTap,
  });

  final int number;
  final String text;
  final bool selected;
  final bool correct;
  final bool wrong;
  final bool enabled;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    Color? background;
    Color border = scheme.outlineVariant;
    if (correct) {
      background = scheme.primaryContainer;
      border = scheme.primary;
    } else if (wrong) {
      background = scheme.errorContainer;
      border = scheme.error;
    } else if (selected) {
      background = scheme.secondaryContainer;
      border = scheme.secondary;
    }

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: background ?? scheme.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: BorderSide(color: border),
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: enabled ? onTap : null,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 15),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                CircleAvatar(
                  radius: 14,
                  child: Text('$number', style: const TextStyle(fontSize: 13)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(text, style: const TextStyle(fontSize: 16, height: 1.5)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
