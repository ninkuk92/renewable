import 'package:flutter/material.dart';

import '../data/progress_store.dart';
import '../data/question_repository.dart';
import '../models/answer_history.dart';
import '../models/question.dart';
import 'quiz_launcher.dart';

enum SavedQuestionMode { wrong, bookmark, weak }

class SavedQuestionsPage extends StatefulWidget {
  const SavedQuestionsPage({super.key, required this.mode});

  final SavedQuestionMode mode;

  @override
  State<SavedQuestionsPage> createState() => _SavedQuestionsPageState();
}

class _SavedQuestionsPageState extends State<SavedQuestionsPage> {
  List<ExamQuestion> _questions = const <ExamQuestion>[];
  bool _loading = true;
  Map<int, AnswerHistory> _history = const <int, AnswerHistory>{};

  String get _title {
    switch (widget.mode) {
      case SavedQuestionMode.wrong:
        return '누적 오답 다시 풀기';
      case SavedQuestionMode.bookmark:
        return '중요문제';
      case SavedQuestionMode.weak:
        return '취약문제';
    }
  }

  String get _emptyMessage {
    switch (widget.mode) {
      case SavedQuestionMode.wrong:
        return '아직 오답 기록이 없습니다.\n한 번이라도 틀린 문제는 이후 맞혀도 기록에서 삭제되지 않습니다.';
      case SavedQuestionMode.bookmark:
        return '중요문제로 저장한 문제가 없습니다.';
      case SavedQuestionMode.weak:
        return '취약문제가 아직 없습니다.\n같은 문제를 여러 번 틀리면 자동으로 모입니다.';
    }
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final store = ProgressStore.instance;
      final history = await store.loadHistory();
      Set<int> ids;
      if (widget.mode == SavedQuestionMode.wrong) {
        // wrong_ids가 예전 버전에서 삭제된 적이 있어도 누적 history의 wrongCount로 복구한다.
        ids = history.entries.where((e) => e.value.wrongCount > 0).map((e) => e.key).toSet();
      } else if (widget.mode == SavedQuestionMode.bookmark) {
        ids = await store.loadBookmarkIds();
      } else {
        ids = history.entries
            .where((e) => e.value.wrongCount >= 2 || (e.value.wrongCount > 0 && !e.value.lastCorrect))
            .map((e) => e.key)
            .toSet();
      }
      final questions = await QuestionRepository.instance.anyByIds(ids);
      if (widget.mode == SavedQuestionMode.wrong) {
        questions.sort((a, b) {
          final byWrong = (history[b.id]?.wrongCount ?? 0).compareTo(history[a.id]?.wrongCount ?? 0);
          if (byWrong != 0) return byWrong;
          return a.id.compareTo(b.id);
        });
      }
      if (!mounted) return;
      setState(() {
        _questions = questions;
        _history = history;
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _questions = const <ExamQuestion>[];
        _loading = false;
      });
    }
  }

  Future<void> _start() async {
    if (_questions.isEmpty) return;
    final sessionId = switch (widget.mode) {
      SavedQuestionMode.wrong => 'review-wrong',
      SavedQuestionMode.bookmark => 'review-bookmark',
      SavedQuestionMode.weak => 'review-weak',
    };

    // 오답 재풀이는 매번 새 시험처럼 시작해야 이전 선택/정답 표시가 남지 않는다.
    if (widget.mode == SavedQuestionMode.wrong) {
      await ProgressStore.instance.clearSession(sessionId);
    }

    if (!mounted) return;
    await openQuizWithResume(
      context,
      title: widget.mode == SavedQuestionMode.wrong ? '누적 오답 문제 다시 풀기' : '$_title 다시 풀기',
      sessionId: sessionId,
      questions: _questions,
    );
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_title)),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _questions.isEmpty
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text(
                      _emptyMessage,
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(height: 1.5),
                    ),
                  ),
                )
              : ListView.separated(
                  padding: const EdgeInsets.fromLTRB(12, 12, 12, 110),
                  itemCount: _questions.length + (widget.mode == SavedQuestionMode.wrong ? 1 : 0),
                  separatorBuilder: (_, __) => const SizedBox(height: 6),
                  itemBuilder: (context, index) {
                    if (widget.mode == SavedQuestionMode.wrong && index == 0) {
                      return Card(
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              const Row(
                                children: <Widget>[
                                  Icon(Icons.restart_alt_rounded),
                                  SizedBox(width: 8),
                                  Text('누적 오답 새로 다시 풀기', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
                                ],
                              ),
                              const SizedBox(height: 8),
                              Text(
                                '${_questions.length}개의 누적 오답 문제를 새 시험처럼 다시 풉니다. 다시 맞혀도 오답 기록은 삭제되지 않고, 또 틀리면 누적 오답 횟수가 1회 증가합니다.',
                                style: const TextStyle(height: 1.5),
                              ),
                              const SizedBox(height: 12),
                              SizedBox(
                                width: double.infinity,
                                child: FilledButton.icon(
                                  onPressed: _start,
                                  icon: const Icon(Icons.play_arrow_rounded),
                                  label: Text('누적 오답 ${_questions.length}문제 다시 풀기'),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    }
                    final qIndex = widget.mode == SavedQuestionMode.wrong ? index - 1 : index;
                    final q = _questions[qIndex];
                    return Card(
                      child: ListTile(
                        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                        leading: CircleAvatar(child: Text('${q.displayNumber}')),
                        title: Text(q.question),
                        subtitle: Padding(
                          padding: const EdgeInsets.only(top: 5),
                          child: Text(
                            widget.mode == SavedQuestionMode.wrong
                                ? '${q.subject} · ${q.examDate} · 누적 오답 ${_history[q.id]?.wrongCount ?? 0}회 · 총 풀이 ${_history[q.id]?.attempts ?? 0}회'
                                : '${q.subject} · ${q.examDate}',
                          ),
                        ),
                        trailing: widget.mode == SavedQuestionMode.wrong
                            ? Chip(label: Text('오답 ${_history[q.id]?.wrongCount ?? 0}회'))
                            : null,
                      ),
                    );
                  },
                ),
      floatingActionButton: _questions.isEmpty
          ? null
          : FloatingActionButton.extended(
              onPressed: _start,
              icon: Icon(widget.mode == SavedQuestionMode.wrong ? Icons.restart_alt_rounded : Icons.play_arrow),
              label: Text(widget.mode == SavedQuestionMode.wrong
                  ? '누적 오답 ${_questions.length}문제 재풀이'
                  : '${_questions.length}문제 풀기'),
            ),
    );
  }
}
