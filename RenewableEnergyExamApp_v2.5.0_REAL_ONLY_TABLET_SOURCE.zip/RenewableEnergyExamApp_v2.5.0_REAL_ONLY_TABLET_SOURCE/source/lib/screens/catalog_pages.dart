import 'package:flutter/material.dart';

import '../data/exam_archive_repository.dart';
import '../data/question_repository.dart';
import '../models/exam_archive_entry.dart';
import '../models/question.dart';
import 'quiz_launcher.dart';

class ExamRoundPage extends StatefulWidget {
  const ExamRoundPage({super.key});
  @override
  State<ExamRoundPage> createState() => _ExamRoundPageState();
}

class _ExamRoundPageState extends State<ExamRoundPage> {
  List<ExamArchiveEntry> _catalog = const <ExamArchiveEntry>[];
  bool _loading = true;
  String? _error;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    try {
      final c = await ExamArchiveRepository.instance.load();
      if (!mounted) return;
      setState(() { _catalog = c; _loading = false; _error = null; });
    } catch (e) {
      if (!mounted) return;
      setState(() { _loading = false; _error = e.toString(); });
    }
  }

  Future<void> _open(ExamArchiveEntry exam) async {
    final q = await QuestionRepository.instance.loadExam(exam.id);
    if (!mounted) return;
    if (q.length != exam.questionCount) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${exam.dateLabel} 데이터 확인 필요: ${q.length}/${exam.questionCount}문제')));
      return;
    }
    await openQuizWithResume(context, title: '${exam.dateLabel} ${exam.round} 기출', sessionId: 'exam-${exam.id}-all', questions: q);
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (_error != null) return Scaffold(appBar: AppBar(title: const Text('회차별 기출')), body: Center(child: Text(_error!)));
    final years = _catalog.map((e) => e.year).toSet().toList()..sort((a,b)=>b.compareTo(a));
    final total = _catalog.fold<int>(0,(s,e)=>s+e.questionCount);
    return Scaffold(
      appBar: AppBar(title: const Text('회차별 기출 · 완전 오프라인')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(12,10,12,28),
        children: <Widget>[
          Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
            const Text('라이브러리 원문 23회차 완전 내장', style: TextStyle(fontWeight: FontWeight.w900,fontSize:19)),
            const SizedBox(height:7),
            Text('2013~2022 · 총 $total문제 · 추가 다운로드 필요 없음'),
            const SizedBox(height:8),
            const Text('교사용 HWP/PDF에서 문제·보기·정답을 추출해 앱에 직접 넣었습니다. 원문의 그림 보기 문항도 함께 내장했습니다.', style: TextStyle(height:1.45)),
          ]))),
          for (final year in years) ...<Widget>[
            Padding(padding: const EdgeInsets.fromLTRB(6,16,6,8), child: Text('$year년', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900))),
            for (final exam in _catalog.where((e)=>e.year==year))
              Card(margin: const EdgeInsets.only(bottom:8), child: ListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal:14,vertical:8),
                leading: const CircleAvatar(child: Icon(Icons.offline_bolt_rounded)),
                title: Text('${exam.dateLabel} · ${exam.round}', style: const TextStyle(fontWeight: FontWeight.w900)),
                subtitle: Text('${exam.questionCount}문제 · ${exam.subjectCount}과목 · 앱 완전 내장'),
                trailing: const Icon(Icons.play_arrow_rounded), onTap: ()=>_open(exam),
              )),
          ],
        ],
      ),
    );
  }
}

class SubjectStudyPage extends StatefulWidget {
  const SubjectStudyPage({super.key});
  @override
  State<SubjectStudyPage> createState() => _SubjectStudyPageState();
}

class _SubjectStudyPageState extends State<SubjectStudyPage> {
  List<ExamQuestion> _questions = const <ExamQuestion>[];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final q = await QuestionRepository.instance.loadReal(refresh: true);
    if (!mounted) return;
    setState(() {
      _questions = q;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final subjects = _questions.map((q) => q.subject).toSet().toList(growable: false)..sort();
    return Scaffold(
      appBar: AppBar(title: const Text('과목별 학습')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: subjects.length,
              itemBuilder: (context, index) {
                final subject = subjects[index];
                final questions = _questions.where((q) => q.subject == subject).toList(growable: false);
                return Card(
                  margin: const EdgeInsets.only(bottom: 10),
                  child: ListTile(
                    leading: CircleAvatar(child: Text('${index + 1}')),
                    title: Text(subject, style: const TextStyle(fontWeight: FontWeight.w800)),
                    subtitle: Text('${questions.length}문제 · 앱 내장 전체 과년도 포함'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => openQuizWithResume(
                      context,
                      title: subject,
                      sessionId: 'subject-all-$subject',
                      questions: questions,
                    ),
                  ),
                );
              },
            ),
    );
  }
}
