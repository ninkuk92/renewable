import 'dart:math';

import 'package:flutter/material.dart';

import '../data/progress_store.dart';
import '../data/question_repository.dart';
import '../models/question.dart';
import '../models/study_session.dart';
import 'catalog_pages.dart';
import 'quiz_launcher.dart';
import 'quiz_page.dart';
import 'saved_questions_page.dart';
import 'stats_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final QuestionRepository _repo = QuestionRepository.instance;
  final ProgressStore _store = ProgressStore.instance;

  List<ExamQuestion> _real = const <ExamQuestion>[];
  List<ExamQuestion> _latest = const <ExamQuestion>[];
  StudySession? _latestSession;
  StudySession? _recentSession;
  int _wrongCount = 0;
  int _bookmarkCount = 0;
  int _weakCount = 0;
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final real = await _repo.loadReal(refresh: true);
      final latest = await _repo.loadExam('2022-04-24');
      final latestSession = await _store.loadSession('exam-2022-04-24-all');
      final recentSession = await _store.loadMostRecentSession();
      final bookmark = await _store.loadBookmarkIds();
      final history = await _store.loadHistory();
      final realIds = real.map((q) => q.id).toSet();
      final weakIds = history.entries
          .where((e) => realIds.contains(e.key))
          .where((e) => e.value.wrongCount >= 2 || (e.value.wrongCount > 0 && !e.value.lastCorrect))
          .map((e) => e.key)
          .toSet();
      if (!mounted) return;
      setState(() {
        _real = real;
        _latest = latest;
        _latestSession = latestSession;
        _recentSession = recentSession;
        _wrongCount = history.entries.where((e) => realIds.contains(e.key) && e.value.wrongCount > 0).length;
        _bookmarkCount = bookmark.length;
        _weakCount = weakIds.length;
        _loading = false;
        _error = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = e.toString();
      });
    }
  }

  Future<void> _push(Widget page) async {
    await Navigator.of(context).push<void>(MaterialPageRoute<void>(builder: (_) => page));
    await _load();
  }

  Future<void> _startLatest() async {
    await openQuizWithResume(
      context,
      title: '2022.04.24 기출 전체',
      sessionId: 'exam-2022-04-24-all',
      questions: _latest,
    );
    await _load();
  }

  Future<void> _startRandom() async {
    if (_real.isEmpty) return;
    final saved = await _store.loadSession('random-current');
    if (!mounted) return;
    if (saved != null && saved.questionIds.isNotEmpty && saved.answeredCount > 0 && !saved.completed) {
      final resume = await showDialog<bool>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('랜덤 모의고사 이어풀기'),
          content: Text('${saved.answeredCount}/${saved.questionIds.length}문제를 풀었습니다.'),
          actions: <Widget>[
            TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('새로 만들기')),
            FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('이어풀기')),
          ],
        ),
      );
      if (resume == null) return;
      if (resume) {
        final questions = await _repo.realByIds(saved.questionIds);
        if (!mounted) return;
        await Navigator.of(context).push<void>(
          MaterialPageRoute<void>(builder: (_) => QuizPage(title: '랜덤 모의고사', sessionId: 'random-current', questions: questions)),
        );
        await _load();
        return;
      }
    }

    if (!mounted) return;
    final max = _real.length;
    final choices = <int>[20, 40, 80, 100].where((n) => n <= max).toList();
    if (!choices.contains(min(200, max)) && max > 100) choices.add(min(200, max));
    final count = await showModalBottomSheet<int>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              const Text('랜덤 모의고사 문제 수', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
              const SizedBox(height: 6),
              Text('현재 앱 내부 DB $max문제에서 무작위 출제'),
              const SizedBox(height: 12),
              for (final n in choices)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: FilledButton.tonal(onPressed: () => Navigator.pop(sheetContext, n), child: Text('$n문제')),
                ),
            ],
          ),
        ),
      ),
    );
    if (count == null) return;
    final shuffled = List<ExamQuestion>.of(_real)..shuffle(Random());
    final questions = shuffled.take(min(count, shuffled.length)).toList(growable: false);
    await _store.clearSession('random-current');
    if (!mounted) return;
    await Navigator.of(context).push<void>(
      MaterialPageRoute<void>(builder: (_) => QuizPage(title: '랜덤 모의고사 $count문제', sessionId: 'random-current', questions: questions)),
    );
    await _load();
  }

  String _recentTitle(StudySession session) {
    final id = session.sessionId;
    if (id.startsWith('exam-') && id.endsWith('-all')) {
      return '${id.substring(5, id.length - 4).replaceAll('-', '.')} 기출';
    }
    if (id.startsWith('subject-all-')) return id.substring('subject-all-'.length);
    if (id == 'random-current') return '랜덤 모의고사';
    if (id == 'review-wrong') return '누적 오답 다시 풀기';
    if (id == 'review-bookmark') return '중요문제 다시 풀기';
    if (id == 'review-weak') return '취약문제 다시 풀기';
    return '최근 학습';
  }

  Future<void> _openRecent() async {
    final session = _recentSession;
    if (session == null) return;
    final questions = await _repo.realByIds(session.questionIds);
    if (!mounted) return;
    await openQuizWithResume(
      context,
      title: _recentTitle(session),
      sessionId: session.sessionId,
      questions: questions,
    );
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (_error != null) {
      return Scaffold(
        appBar: AppBar(title: const Text('신재생에너지 기사 오답노트')),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisSize: MainAxisSize.min, children: <Widget>[
              const Icon(Icons.error_outline, size: 48),
              const SizedBox(height: 12),
              Text('문제 데이터를 불러오지 못했습니다.\n$_error', textAlign: TextAlign.center),
              const SizedBox(height: 16),
              FilledButton(onPressed: _load, child: const Text('다시 시도')),
            ]),
          ),
        ),
      );
    }

    final progress = _latestSession?.answeredCount ?? 0;
    final canResume = progress > 0 && _latestSession?.completed != true;
    return Scaffold(
      appBar: AppBar(title: const Text('신재생에너지 기사 오답노트')),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 28),
          children: <Widget>[
            if (_recentSession != null) ...<Widget>[
              Card(
                color: Theme.of(context).colorScheme.secondaryContainer,
                child: ListTile(
                  leading: const CircleAvatar(child: Icon(Icons.history_rounded)),
                  title: Text('최근 공부 · ${_recentTitle(_recentSession!)}', style: const TextStyle(fontWeight: FontWeight.w900)),
                  subtitle: Text('${_recentSession!.answeredCount}/${_recentSession!.questionIds.length}문제 · 마지막 위치 ${_recentSession!.currentIndex + 1}번'),
                  trailing: const Icon(Icons.play_arrow_rounded),
                  onTap: _openRecent,
                ),
              ),
              const SizedBox(height: 8),
            ],
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
                  const Text('과년도 전체 CBT DB', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 6),
                  Text('23/23회차 완전 내장 · 현재 ${_real.length}문제 사용 가능'),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: () => _push(const ExamRoundPage()),
                      icon: const Icon(Icons.offline_bolt_rounded),
                      label: const Text('23회차 전체 내장 · 회차 선택'),
                    ),
                  ),
                ]),
              ),
            ),
            if (canResume) ...<Widget>[
              const SizedBox(height: 8),
              Card(
                child: ListTile(
                  leading: const CircleAvatar(child: Icon(Icons.play_arrow_rounded)),
                  title: const Text('2022.04.24 이어풀기', style: TextStyle(fontWeight: FontWeight.w900)),
                  subtitle: Text('$progress/${_latest.length}문제 · 현재 ${(_latestSession?.currentIndex ?? 0) + 1}번'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: _startLatest,
                ),
              ),
            ],
            const SizedBox(height: 8),
            _MenuTile(icon: Icons.menu_book_rounded, title: '회차별 기출', subtitle: '2013~2022 · 23회차 · 2,140문제 완전 오프라인', onTap: () => _push(const ExamRoundPage())),
            _MenuTile(icon: Icons.library_books_outlined, title: '과목별 학습', subtitle: '내장된 과년도 전체에서 과목별 학습', onTap: () => _push(const SubjectStudyPage())),
            _MenuTile(icon: Icons.error_outline_rounded, title: '틀린 문제 다시 풀기', subtitle: '누적 오답 기록 $_wrongCount문제 · 맞혀도 기록 유지', onTap: () => _push(const SavedQuestionsPage(mode: SavedQuestionMode.wrong))),
            _MenuTile(icon: Icons.star_border_rounded, title: '중요문제', subtitle: '저장 $_bookmarkCount문제', onTap: () => _push(const SavedQuestionsPage(mode: SavedQuestionMode.bookmark))),
            _MenuTile(icon: Icons.warning_amber_rounded, title: '취약문제', subtitle: '반복 오답 $_weakCount문제', onTap: () => _push(const SavedQuestionsPage(mode: SavedQuestionMode.weak))),
            _MenuTile(icon: Icons.quiz_outlined, title: '랜덤 모의고사', subtitle: '현재 저장된 ${_real.length}문제에서 랜덤 출제', onTap: _startRandom),
            _MenuTile(icon: Icons.bar_chart_rounded, title: '학습 통계', subtitle: '전체 과년도 풀이 · 정답 · 오답 현황', onTap: () => _push(const StatsPage())),
            const SizedBox(height: 8),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 6),
              child: Text('문제를 풀 때마다 답안과 현재 위치가 자동 저장됩니다. 회차별 진행 기록은 서로 분리됩니다.', style: TextStyle(fontSize: 12.5, height: 1.5)),
            ),
          ],
        ),
      ),
    );
  }
}

class _MenuTile extends StatelessWidget {
  const _MenuTile({required this.icon, required this.title, required this.subtitle, required this.onTap});
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Card(
        margin: const EdgeInsets.only(bottom: 8),
        child: ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          leading: Icon(icon),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
          subtitle: Text(subtitle),
          trailing: const Icon(Icons.chevron_right),
          onTap: onTap,
        ),
      );
}
