import 'package:flutter/material.dart';

import '../data/progress_store.dart';
import '../data/question_repository.dart';
import '../models/answer_history.dart';
import '../models/question.dart';

class StatsPage extends StatefulWidget {
  const StatsPage({super.key});

  @override
  State<StatsPage> createState() => _StatsPageState();
}

class _StatsPageState extends State<StatsPage> {
  bool _loading = true;
  List<ExamQuestion> _questions = const <ExamQuestion>[];
  Map<int, AnswerHistory> _history = const <int, AnswerHistory>{};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final repo = QuestionRepository.instance;
    final store = ProgressStore.instance;
    final questions = await repo.loadReal();
    final history = await store.loadHistory();
    if (!mounted) return;
    setState(() {
      _questions = questions;
      _history = history;
      _loading = false;
    });
  }

  int get _attemptedReal => _questions.where((q) => _history.containsKey(q.id)).length;
  int get _lastCorrectReal => _questions.where((q) => _history[q.id]?.lastCorrect == true).length;
  int get _wrongRecordedReal => _questions.where((q) => (_history[q.id]?.wrongCount ?? 0) > 0).length;
  int get _totalWrongAttempts => _questions.fold<int>(0, (sum, q) => sum + (_history[q.id]?.wrongCount ?? 0));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('학습 통계')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Expanded(child: _StatCard(title: '기출 풀이', value: '$_attemptedReal/${_questions.length}')),
                      const SizedBox(width: 10),
                      Expanded(child: _StatCard(title: '최근 정답', value: '$_lastCorrectReal')),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: <Widget>[
                      Expanded(child: _StatCard(title: '오답 기록 문제', value: '$_wrongRecordedReal')),
                      const SizedBox(width: 10),
                      Expanded(child: _StatCard(title: '누적 오답 횟수', value: '$_totalWrongAttempts')),
                    ],
                  ),
                  const SizedBox(height: 24),
                  Text('과목별 현황', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
                  const SizedBox(height: 10),
                  for (final subject in _questions.map((q) => q.subject).toSet())
                    _SubjectStatCard(
                      subject: subject,
                      questions: _questions.where((q) => q.subject == subject).toList(growable: false),
                      history: _history,
                    ),
                  const SizedBox(height: 18),
                  OutlinedButton.icon(
                    onPressed: _confirmReset,
                    icon: const Icon(Icons.delete_outline),
                    label: const Text('학습 기록 전체 초기화'),
                  ),
                ],
              ),
            ),
    );
  }

  Future<void> _confirmReset() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('학습 기록 초기화'),
        content: const Text('이어풀기, 오답, 중요문제, 통계를 모두 삭제합니다. 계속할까요?'),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('취소')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('초기화')),
        ],
      ),
    );
    if (ok != true) return;
    await ProgressStore.instance.resetAllLearningData();
    await _load();
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({required this.title, required this.value});
  final String title;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(title, style: Theme.of(context).textTheme.bodyMedium),
            const SizedBox(height: 6),
            Text(value, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900)),
          ],
        ),
      ),
    );
  }
}

class _SubjectStatCard extends StatelessWidget {
  const _SubjectStatCard({required this.subject, required this.questions, required this.history});

  final String subject;
  final List<ExamQuestion> questions;
  final Map<int, AnswerHistory> history;

  @override
  Widget build(BuildContext context) {
    final attempted = questions.where((q) => history.containsKey(q.id)).length;
    final correct = questions.where((q) => history[q.id]?.lastCorrect == true).length;
    final ratio = questions.isEmpty ? 0.0 : attempted / questions.length;
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(subject, style: const TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            LinearProgressIndicator(value: ratio),
            const SizedBox(height: 8),
            Text('풀이 $attempted/${questions.length} · 최근 정답 $correct'),
          ],
        ),
      ),
    );
  }
}
