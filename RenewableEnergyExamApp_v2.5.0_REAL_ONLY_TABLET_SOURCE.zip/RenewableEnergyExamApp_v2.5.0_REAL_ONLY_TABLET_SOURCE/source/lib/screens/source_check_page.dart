import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class SourceCheckPage extends StatelessWidget {
  const SourceCheckPage({super.key, required this.title, required this.url});

  final String title;
  final String url;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title, overflow: TextOverflow.ellipsis)),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: <Widget>[
            const Icon(Icons.fact_check_outlined, size: 54),
            const SizedBox(height: 14),
            const Text(
              '원문 주소',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 10),
            const Text(
              '앱 문제는 내부 DB로 저장되어 오프라인에서도 풀 수 있습니다. '
              '그림·표·수식 등 원문 대조가 필요한 경우 아래 주소를 복사해 브라우저에서 확인하세요.',
              style: TextStyle(fontSize: 15.5, height: 1.55),
            ),
            const SizedBox(height: 18),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: SelectableText(url, style: const TextStyle(fontSize: 15, height: 1.5)),
              ),
            ),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: () async {
                await Clipboard.setData(ClipboardData(text: url));
                if (!context.mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('원문 주소를 복사했습니다.')),
                );
              },
              icon: const Icon(Icons.copy_rounded),
              label: const Text('주소 복사'),
            ),
          ],
        ),
      ),
    );
  }
}
