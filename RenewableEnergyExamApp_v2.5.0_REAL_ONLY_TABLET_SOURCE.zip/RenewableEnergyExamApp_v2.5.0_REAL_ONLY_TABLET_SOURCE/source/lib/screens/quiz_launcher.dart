import 'package:flutter/material.dart';

import '../data/progress_store.dart';
import '../models/question.dart';
import 'quiz_page.dart';

enum _ResumeAction { resume, restart }

Future<void> openQuizWithResume(
  BuildContext context, {
  required String title,
  required String sessionId,
  required List<ExamQuestion> questions,
}) async {
  if (questions.isEmpty) {
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('표시할 문제가 없습니다.')),
    );
    return;
  }

  final store = ProgressStore.instance;
  final saved = await store.loadSession(sessionId);
  if (!context.mounted) return;

  if (saved != null && saved.answeredCount > 0 && !saved.completed) {
    final action = await showDialog<_ResumeAction>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('이어풀기 기록이 있습니다'),
        content: Text(
          '${saved.answeredCount}/${questions.length}문제를 풀었습니다. '
          '마지막 위치 ${saved.currentIndex + 1}번부터 이어서 볼 수 있습니다.',
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, _ResumeAction.restart),
            child: const Text('처음부터'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, _ResumeAction.resume),
            child: const Text('이어풀기'),
          ),
        ],
      ),
    );
    if (action == null) return;
    if (action == _ResumeAction.restart) {
      await store.clearSession(sessionId);
    }
  } else if (saved?.completed == true) {
    final restart = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('완료한 학습입니다'),
        content: const Text('처음부터 다시 풀까요?'),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('취소')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('다시 풀기')),
        ],
      ),
    );
    if (restart != true) return;
    await store.clearSession(sessionId);
  }

  if (!context.mounted) return;
  await Navigator.of(context).push<void>(
    MaterialPageRoute<void>(
      builder: (_) => QuizPage(title: title, sessionId: sessionId, questions: questions),
    ),
  );
}
