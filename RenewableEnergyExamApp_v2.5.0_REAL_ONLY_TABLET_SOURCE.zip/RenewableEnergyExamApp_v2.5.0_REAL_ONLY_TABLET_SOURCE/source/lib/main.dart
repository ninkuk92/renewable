import 'package:flutter/material.dart';

import 'screens/home_page.dart';

void main() => runApp(const RenewableExamApp());

class RenewableExamApp extends StatelessWidget {
  const RenewableExamApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: '신재생에너지 기사 CBT',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF8D5A8F),
        scaffoldBackgroundColor: const Color(0xFFFFF8FF),
      ),
      home: const _SafeBootPage(),
    );
  }
}

class _SafeBootPage extends StatefulWidget {
  const _SafeBootPage();

  @override
  State<_SafeBootPage> createState() => _SafeBootPageState();
}

class _SafeBootPageState extends State<_SafeBootPage> {
  bool _opening = false;

  @override
  void initState() {
    super.initState();
    Future<void>.delayed(const Duration(milliseconds: 900), _openHome);
  }

  void _openHome() {
    if (!mounted || _opening) return;
    _opening = true;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute<void>(builder: (_) => const HomePage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                const Icon(Icons.solar_power_rounded, size: 64),
                const SizedBox(height: 16),
                const Text(
                  '신재생에너지 기사 CBT',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 10),
                const Text('v2.5.0 · 실제 기출 전용 + 전체 그림'),
                const SizedBox(height: 18),
                const CircularProgressIndicator(),
                const SizedBox(height: 18),
                OutlinedButton(
                  onPressed: _openHome,
                  child: const Text('홈 화면 열기'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
