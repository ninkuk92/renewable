@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"

set "LOG=%~dp0BUILD_LOG.txt"
set "PROBE=%~dp0FLUTTER_CHECK.txt"
set "APPDIR=%~dp0generated_project"
set "APKOUT=%~dp0RenewableEnergyExam_v2.5.0_REAL_ONLY_TABLET_DEBUG.apk"
set "FLUTTER_CMD="

>"%LOG%" echo BUILD SCRIPT STARTED
>>"%LOG%" echo DATE: %date% %time%
>>"%LOG%" echo FOLDER: %CD%
>"%PROBE%" echo Flutter SDK check

cls
echo =============================================================
echo Renewable Energy Exam APK Builder v2.5.0 REAL QUESTIONS + TABLET
echo =============================================================
echo.
echo Phone connection is NOT required.
echo This build uses the vanilla Flutter Android project.
echo All 23 exam rounds are bundled offline. No third-party runtime Flutter plugins are included.
echo.
echo Press any key to start.
pause >nul

if not exist "%~dp0source\pubspec.yaml" (
  echo ERROR: source\pubspec.yaml not found.
  >>"%LOG%" echo ERROR: source\pubspec.yaml not found.
  goto :FAIL
)

call :TRY_FLUTTER "C:\makeapp\flutter\bin\flutter.bat"
if not defined FLUTTER_CMD call :TRY_FLUTTER "C:\flutter\bin\flutter.bat"
if not defined FLUTTER_CMD call :TRY_FLUTTER "C:\src\flutter\bin\flutter.bat"
if not defined FLUTTER_CMD call :TRY_FLUTTER "%USERPROFILE%\flutter\bin\flutter.bat"
if not defined FLUTTER_CMD call :TRY_FLUTTER "%USERPROFILE%\development\flutter\bin\flutter.bat"
if not defined FLUTTER_CMD call :TRY_FLUTTER "%LOCALAPPDATA%\flutter\bin\flutter.bat"
if not defined FLUTTER_CMD call :TRY_FLUTTER "D:\flutter\bin\flutter.bat"
if not defined FLUTTER_CMD (
  for /f "delims=" %%F in ('where flutter.bat 2^>nul') do call :TRY_FLUTTER "%%F"
)

if not defined FLUTTER_CMD (
  echo ERROR: No WORKING Flutter SDK was found.
  >>"%LOG%" echo ERROR: No WORKING Flutter SDK was found.
  goto :FAIL
)

echo Using Flutter: %FLUTTER_CMD%
>>"%LOG%" echo Using Flutter: %FLUTTER_CMD%

if exist "%APPDIR%" rmdir /s /q "%APPDIR%"
if exist "%APKOUT%" del /q "%APKOUT%"

echo [1/6] Creating VANILLA Flutter Android project...
call "%FLUTTER_CMD%" create --platforms=android --org com.renewableexam --project-name renewable_exam_app "%APPDIR%" >>"%LOG%" 2>&1
if errorlevel 1 goto :FAIL

echo [2/6] Copying Dart source and assets...
copy /y "%~dp0source\pubspec.yaml" "%APPDIR%\pubspec.yaml" >nul
copy /y "%~dp0source\analysis_options.yaml" "%APPDIR%\analysis_options.yaml" >nul
if exist "%APPDIR%\lib" rmdir /s /q "%APPDIR%\lib"
xcopy /e /i /y "%~dp0source\lib" "%APPDIR%\lib" >nul
if exist "%APPDIR%\assets" rmdir /s /q "%APPDIR%\assets"
xcopy /e /i /y "%~dp0source\assets" "%APPDIR%\assets" >nul
if exist "%APPDIR%\test" rmdir /s /q "%APPDIR%\test"

rem Keep Flutter's generated Android project untouched. Only add INTERNET permission.
set "MANIFEST=%APPDIR%\android\app\src\main\AndroidManifest.xml"
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$p='%MANIFEST%'; $s=Get-Content -Raw $p; if($s -notmatch 'android.permission.INTERNET'){ $s=$s -replace '(<manifest[^>]*>)','$1`r`n    <uses-permission android:name=\"android.permission.INTERNET\" />' }; $s=$s -replace 'android:label=\"[^\"]*\"','android:label=\"신재생에너지 기사 CBT\"'; Set-Content -Path $p -Value $s -Encoding UTF8" >>"%LOG%" 2>&1
if errorlevel 1 goto :FAIL

cd /d "%APPDIR%"
echo [3/6] Getting packages...
call "%FLUTTER_CMD%" pub get >>"%LOG%" 2>&1
if errorlevel 1 goto :FAIL

echo [4/6] Checking source...
call "%FLUTTER_CMD%" analyze --no-fatal-infos --no-fatal-warnings >>"%LOG%" 2>&1
if errorlevel 1 goto :FAIL

echo [5/6] Building debug APK...
call "%FLUTTER_CMD%" build apk --debug >>"%LOG%" 2>&1
if errorlevel 1 goto :FAIL

echo [6/6] Copying APK...
if not exist "%APPDIR%\build\app\outputs\flutter-apk\app-debug.apk" (
  >>"%LOG%" echo ERROR: app-debug.apk was not produced.
  goto :FAIL
)
copy /y "%APPDIR%\build\app\outputs\flutter-apk\app-debug.apk" "%APKOUT%" >nul
if errorlevel 1 goto :FAIL

cd /d "%~dp0"
>>"%LOG%" echo SUCCESS: %APKOUT%
echo.
echo =============================================================
echo SUCCESS
echo APK: RenewableEnergyExam_v2.5.0_REAL_ONLY_TABLET_DEBUG.apk
echo =============================================================
echo.
explorer /select,"%APKOUT%" >nul 2>&1
echo Press any key to close.
pause >nul
exit /b 0

:TRY_FLUTTER
if defined FLUTTER_CMD exit /b 0
set "CANDIDATE=%~1"
if not exist "%CANDIDATE%" (
  >>"%PROBE%" echo NOT FOUND: %CANDIDATE%
  exit /b 0
)
>>"%PROBE%" echo.
>>"%PROBE%" echo TESTING: %CANDIDATE%
call "%CANDIDATE%" --version >>"%PROBE%" 2>&1
if errorlevel 1 (
  >>"%PROBE%" echo RESULT: REJECTED
  exit /b 0
)
set "FLUTTER_CMD=%CANDIDATE%"
>>"%PROBE%" echo RESULT: OK
exit /b 0

:FAIL
cd /d "%~dp0"
echo.
echo =============================================================
echo BUILD FAILED
echo =============================================================
echo.
if exist "%LOG%" powershell -NoProfile -Command "Get-Content -Path '%LOG%' -Tail 140" 2>nul
echo.
echo Press any key to close.
pause >nul
exit /b 1
