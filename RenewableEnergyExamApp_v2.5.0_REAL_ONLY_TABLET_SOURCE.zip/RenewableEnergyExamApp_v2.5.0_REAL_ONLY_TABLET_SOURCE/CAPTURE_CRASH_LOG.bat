@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "ADB="
set "OUT=%~dp0CRASH_LOG.txt"

if defined ANDROID_HOME if exist "%ANDROID_HOME%\platform-tools\adb.exe" set "ADB=%ANDROID_HOME%\platform-tools\adb.exe"
if not defined ADB if exist "%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe" set "ADB=%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe"
if not defined ADB if exist "%USERPROFILE%\AppData\Local\Android\Sdk\platform-tools\adb.exe" set "ADB=%USERPROFILE%\AppData\Local\Android\Sdk\platform-tools\adb.exe"
if not defined ADB (
  for /f "delims=" %%A in ('where adb.exe 2^>nul') do if not defined ADB set "ADB=%%A"
)

if not defined ADB (
  echo ADB not found.
  echo Android SDK platform-tools is required only for crash logging.
  pause
  exit /b 1
)

echo ADB: %ADB%
"%ADB%" devices

echo.
echo Make sure USB debugging is enabled and the phone shows as device.
echo Press any key to capture startup crash.
pause >nul

"%ADB%" logcat -c
"%ADB%" shell am force-stop com.renewableexam.renewable_exam_app
"%ADB%" shell monkey -p com.renewableexam.renewable_exam_app -c android.intent.category.LAUNCHER 1 >nul 2>&1
ping 127.0.0.1 -n 6 >nul
"%ADB%" logcat -d -v time > "%OUT%"

echo.
echo Saved: CRASH_LOG.txt
echo Send CRASH_LOG.txt.
pause
