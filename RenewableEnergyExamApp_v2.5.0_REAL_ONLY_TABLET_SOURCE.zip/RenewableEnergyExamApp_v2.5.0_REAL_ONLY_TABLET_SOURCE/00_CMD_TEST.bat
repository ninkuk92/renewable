@echo off
cd /d "%~dp0"
>CMD_TEST_OK.txt echo CMD works.
echo CMD works.
echo CMD_TEST_OK.txt was created.
echo.
pause
